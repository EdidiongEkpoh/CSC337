/* Eddie Ekpoh
Javascript file that represents the client side functions that will be used 
when the user is finished entering their information. Functions will be called 
on the buttons of their sections.
*/

//Uses DOM Elements to create url that will be fetched to get user details
function addUser() {
  let u = document.getElementById('userName').value;
  let pass = document.getElementById('password').value;
  let url = '/add/user/';
  let data = { username: u, password: pass};
  let p = fetch(url, {
    method: 'POST', 
    body: JSON.stringify(data),
    headers: {"Content-Type": "application/json"}
  });
  p.then(() => {
    console.log('User Created');
  });
  p.catch(() => { 
    alert('something went wrong');
  });
}
//Uses DOM Elements to create url that will be fetched to get item details
function addItem() {
  let t = document.getElementById('title').value;
  let d = document.getElementById('desc').value;
  let i = document.getElementById('image').value;
  let pr= document.getElementById('price').value;
  let s = document.getElementById('stat').value;
  let user = document.getElementById("iUserName").value;
  let url = '/add/item/' + user + '/';
  let data = { title: t, description: d, image: i, price: pr, stat: s};
  let p = fetch(url, {
    method: 'POST', 
    body: JSON.stringify(data),
    headers: {"Content-Type": "application/json"}
  });
  p.then(() => {
    console.log('Item Created');
  });
  p.catch(() => { 
    alert('something went wrong');
  });
}


