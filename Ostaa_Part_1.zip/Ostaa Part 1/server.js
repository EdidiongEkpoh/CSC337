/* Eddie Ekpoh
Javascript file that represents the server side of the web page.
Creates schema for Item and User objects and performs various GET/POST
requests that retrieve or add data.
*/

//Required variables
const mongoose = require('mongoose');
const express = require('express');
const fs = require('fs');
const app = express();
const connectionString = 'mongodb+srv://edidionguekpoh:Blessing273AofU02@cluster0.jplgooz.mongodb.net/ostaa';
const port = 80;


app.use(express.static('public_html'))
app.use(express.json())

//Connccting to database
mongoose.connect(connectionString, {useNewUrlParser: true});
mongoose.connection.on('error', () => {
  console.log("There was a problem connecting to mongoDB");
});




//Creation of Schemas
var ItemSchema = new mongoose.Schema({
  title: String,
  description: String,
  image: String,
  price: Number,
  stat: String
})

var Item = mongoose.model('Item', ItemSchema);

var UserSchema = new mongoose.Schema({
  username: String,
  password: String,
  listings: [{type: mongoose.Schema.Types.ObjectId, ref: "Item"}],
  purchases: [{type: mongoose.Schema.Types.ObjectId, ref: "Item"}]
})
var User = mongoose.model('User', UserSchema);


//Returns JSON array containing the information for every user
app.get('/get/users/', (req, res) => {
  let p = User.find({}).exec(); 
  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Returns JSON array containing the information for every item
app.get('/get/items/', (req, res) => {
  let p = Item.find({}).exec();

  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Returns JSON array containing every listing for USERNAME
app.get('/get/listings/:USERNAME', (req, res) => {
  let user = req.params.USERNAME;
  let p = User.find({username:user}).select('listings').exec();

  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Returns JSON array containing every purchase for USERNAME
app.get('/get/purchases/:USERNAME', (req, res) => {
  let user = req.params.USERNAME;
  let p = User.find({username:user}).select('purchases').exec();

  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Returns JSON array containing every username that has a substring of the KEYWORD
app.get('/search/users/:KEYWORD', (req, res) => {
  let key = req.params.KEYWORD;

  let p = User.find({username: {$regex: key, $options: 'i'}}).exec();

  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Returns JSON array containing every item whose description has a substring of the KEYWORD
app.get('/search/items/:KEYWORD', (req, res) => {
  let key = req.params.KEYWORD;

  let p = Item.find({description: {$regex: key, $options: 'i'}}).exec();

  p.then((results) => {
    res.end(JSON.stringify(results))
  });
  p.catch((error) => {
    console.log(error);
    res.end("FAIL");
  });
});

//Adds user to the database. Username and password
app.post('/add/user/', (req, res) => {
  var UserToSave = req.body;

  newUser = new User(UserToSave);
  let p = newUser.save();

  p.then((doc) => {
    res.end("SAVED SUCCESSFULLY");
  });
  p.catch((err) => {
    console.log(err);
    res.end('FAIL');
  })
});

//Adds item to the database (title, description, image,
//price, status)
app.post('/add/item/:USERNAME', (req, res) => {
  var user = req.params.USERNAME;
  var ItemToSave = req.body;
  newItem = new Item(ItemToSave);
  p1 = newItem.save();
  p1.then((doc) => {
    //Accepts "sale" or "purchased" as values
    if (doc.stat.toUpperCase() == "SALE") { 
      User.updateOne({username: user}, {$addToSet: {listings: doc._id}},
        {new:true})
        .then(() => {
            console.log("Item updated successfully");
        })
    
        .catch((err) => {
          console.log("Error adding item: ", err);
        })
    }
    else if (doc.stat.toUpperCase() == "SOLD") {
      User.updateOne({username: user}, {$addToSet: {purchases: doc._id}},
        {new:true})
        .then(() => {
            console.log("Item updated successfully");
        })
    
        .catch((err) => {
          console.log("Error adding item: ", err);
        })
    }
    res.end("SAVED SUCCESSFULLY");
  });
  p1.catch((err) => {
    console.log(err);
    res.end('FAIL');
  })

  

  
});

//Running Server
app.listen(port, () => {
  console.log('Server has started');
});
